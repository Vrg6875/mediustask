from django.contrib import admin
from .models import*

admin.site.register(student)
admin.site.register(section)
admin.site.register(Category)
admin.site.register(Book)
admin.site.register(todo)

# Register your models here.
