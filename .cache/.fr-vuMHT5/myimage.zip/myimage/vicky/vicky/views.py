from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render,redirect
from mohaliform.models import vic_mohaliform

def mohaliform(request):
    mohalidata=vic_mohaliform.objects.all()
    data={'mohalidata':mohalidata}
    return render(request,"mohaliform.html",data)