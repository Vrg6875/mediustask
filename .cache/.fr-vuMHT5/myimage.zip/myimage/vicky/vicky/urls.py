from django.contrib import admin
from django.urls import path, include
from vicky import views  # Import views from the same directory as urls.py

urlpatterns = [
    path('admin/', admin.site.urls),
    path('mohaliform/', views.mohaliform, name='mohaliform'),  # Assuming the view is defined in views.py
    path('', include('home.urls')),  # Include URLs from the 'home' app
]
