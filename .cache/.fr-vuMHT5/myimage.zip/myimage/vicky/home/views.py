from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET', 'POST'])  # Specify the allowed methods
def home(request):
    if request.method == 'GET':
        return Response({
            'status': 200,
            'method': 'get'
        })
    elif request.method == 'POST':
       # Access the 'name' field from POST data
        return Response({
            'status': 200,  # Assuming successful response for POST
            'method': 'post',
            
        })
    else:
        return Response({
            'status': 400,
            'method': 'invalid'
        })
