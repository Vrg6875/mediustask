from django.apps import AppConfig


class MohaliformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mohaliform'
