from django.contrib import admin
from mohaliform.models import vic_mohaliform

class admin_vic(admin.ModelAdmin):
    list_display=('student_name','roll_no','section')
admin.site.register(vic_mohaliform,admin_vic)    

# Register your models here.
