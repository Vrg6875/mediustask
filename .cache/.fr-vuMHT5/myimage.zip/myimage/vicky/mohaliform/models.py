from django.db import models

class vic_mohaliform(models.Model):
    student_name=models.CharField(max_length=50)
    roll_no=models.TextField()
    section=models.CharField(max_length=10)